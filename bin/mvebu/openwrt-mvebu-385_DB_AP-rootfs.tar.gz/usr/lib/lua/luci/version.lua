local pcall, dofile, _G = pcall, dofile, _G

module "luci.version"

if pcall(dofile, "/etc/openwrt_release") and _G.DISTRIB_DESCRIPTION then
	distname    = ""
	distversion = _G.DISTRIB_DESCRIPTION
else
	distname    = "OpenWrt Firmware"
	distversion = "Barrier Breaker (r47068)"
end

luciname    = "LuCI 9e42ff7c6d19f761abb5c83fe73e65198a7e37c1 Branch"
luciversion = "0.12+git-15.274.55010-9e42ff7"
